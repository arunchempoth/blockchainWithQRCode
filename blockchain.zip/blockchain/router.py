import time
from mimetypes import MimeTypes
from flask import Flask, jsonify, request, send_file, render_template, Response
from uuid import uuid4
from io import BytesIO
from blockchain import Blockchain
import qrcode


app = Flask(__name__, static_url_path='/static/')


node_identifier = str(uuid4()).replace('-', '')

blockchain = Blockchain() 

UPLOAD_FOLDER="."


@app.route('/mine', methods=['GET'])
def mine():
    """ This function is used to mine the block with current transactions"""
    last_block = blockchain.get_last_block
    print(last_block)
    last_proof = last_block['proof']
    proof = blockchain.proof_of_work(last_proof)

    blockchain.add_transaction(sender=0, recipient=node_identifier, amount=1)
    block = blockchain.add_block(proof)
    block['message'] = 'New block added'

    return jsonify(block), 200


@app.route('/transactions/new', methods=['GET'])
def new_transaction():
    """ This function is used to add a transaction to the current transactions list"""

    # data = request.get_json()
    ''' Hardcoding for POC purposes'''
    data = {'sender':'Arun', 'recipient': 'Vinay', 'amount':5}

    if not data:
        return "No transation data passed", 400

    required = ['sender', 'recipient', 'amount']

    if not (list(data.keys()) == required):
        return 'Missing Value', 400
    
    block_index = blockchain.add_transaction(data['sender'], data['recipient'], data['amount'])
    response = {'message':f'Adding the transaction to block at index: {block_index}'}
    chain_url = {'chain_url ':'http://127.0.0.1:5000/chain'}
    qr_code_filename= generate_qr_code(chain_url)
    data=[response,chain_url, {'qr_code':f'{qr_code_filename}'}]
    
    print("QR Code File", qr_code_filename)
    print("\nData", data)
    # Uncomment this for html view
    return render_template("newTransactionResponse.html",urls=data)
    

    # return jsonify(data), 201
    
def generate_qr_code(url):
    # # URL to be converted to QR code
    img = qrcode.make(url)
    filename = UPLOAD_FOLDER + time.strftime("%Y%m%d%H%M%S")+"qrcode.png"
    img.save(filename)
    return filename
    
    
"""
cURL request: 
 
curl -X POST -H "Content-Type: application/json" -d '{"sender": "Arun", "recipient": "Vinay", "amount": 5}' "http://localhost:5000/transactions/new" 


"""

# @app.route('/nodes/register', methods=['POST'])
# def register_nodes():
#     nodes = request.get_json().get('nodes')
#     if nodes is None:
#         return " Need valid nodes to register", 400
#
#     for node in nodes:
#         blockchain.register_node(node)
#
#     response = {
#         'message': 'Added more nodes to the network',
#         'list_of_nodes': list(self.nodes)
#     }
#

    # return jsonify(response), 201


@app.route('/nodes/resolve', methods=['GET'])
def consensus():
    replaced = blockchain.resolve_conflicts()

    if replaced:
        response = {
            'message': 'This chain was replaced by another chain',
            'new_chain': blockchain.chain
        }
        
        return jsonify(response), 201

    else:
        response = {
            'message': 'This chain was not replaced',
            'chain': blockchain.chain
        }

        return jsonify(response), 200
    
    
@app.route('/chain', methods=['GET'])
def get_chain():
    """ This function is used to get the chain data """
    response = {
        'chain': blockchain.chain,
        'length':len(blockchain.chain)
    }

    # return jsonify(response), 200
    return render_template("index.html",transactions=[response])



if __name__=='__main__':
    app.run(host='0.0.0.0', port=5000)